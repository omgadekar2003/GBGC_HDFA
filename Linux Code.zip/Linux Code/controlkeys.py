from pynput.keyboard import Key, Controller
import time

keyboard = Controller()

# Define key mappings
up_pressed = 'w'
down_pressed = 's'
right_pressed = 'd'
left_pressed = 'a'

def KeyOn(key):
    """
    Simulates key press.
    """
    keyboard.press(key)

def KeyOff(key):
    """
    Simulates key release.
    """
    keyboard.release(key)

if __name__ == '__main__':
    while True:
        KeyOn('w')  # Simulates pressing the 'W' key
        time.sleep(1)
        KeyOff('w')  # Simulates releasing the 'W' key
        time.sleep(1)
