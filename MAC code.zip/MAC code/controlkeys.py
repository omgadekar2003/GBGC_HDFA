
from pynput.keyboard import Controller, Key

keyboard = Controller()

# Define key mappings for cross-platform compatibility
up_pressed = Key.up
down_pressed = Key.down
right_pressed = Key.right
left_pressed = Key.left

def KeyOn(key):
    """Presses a key."""
    keyboard.press(key)

def KeyOff(key):
    """Releases a key."""
    keyboard.release(key)



