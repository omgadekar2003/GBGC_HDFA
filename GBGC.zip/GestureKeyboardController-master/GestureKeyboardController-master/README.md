# Gesture Based Game Control
A tool to control games using hand gestures!!
Current functionality - Accelerate,Brake/Reverse,Left,Right.

Usage:

Accelerate-1 finger  (Finger no.2) finger

Brake/Reverse- 0 fingers/closed wrist

Left- only left palm open

Right- only right palm open

See Home Page Video to Use Gestures Correctly to Play Game.
